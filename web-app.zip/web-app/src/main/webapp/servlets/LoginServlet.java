package main.webapp.servlets;


import main.webapp.jdbc.dao.UsersDAO;
import main.webapp.jdbc.dao.impl.UserDAOImpl;
import main.webapp.model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LoginServlet extends HttpServlet {



    private static UsersDAO dao = new UserDAOImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");

        String email = req.getParameter("email");
        String pwd = req.getParameter("pwd");

        User user = dao.getUserByEmail(email);

        if(user == null || !user.getPwd().equals(pwd)){
            RequestDispatcher disp = req.getRequestDispatcher("LoginForm.html");

            resp.getWriter().println("Ooops! Wrong credentials. <a href='regme'>REGISTRATION<a> ");
            disp.include(req, resp);
        } else if(email.equalsIgnoreCase(user.getEmail()) && pwd.equals(user.getPwd())) {
            resp.getWriter().println("Welcome hello! " + user.getName());
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher disp = req.getRequestDispatcher("LoginForm.html");
        disp.forward(req, resp);
    }
}
