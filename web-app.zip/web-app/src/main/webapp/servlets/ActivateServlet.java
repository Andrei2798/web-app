package main.webapp.servlets;


import javax.servlet.http.HttpServlet;


public class ActivateServlet extends HttpServlet
{




}
