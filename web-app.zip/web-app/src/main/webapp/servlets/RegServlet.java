package main.webapp.servlets;

import main.webapp.jdbc.dao.UsersDAO;
import main.webapp.jdbc.dao.impl.UserDAOImpl;
import main.webapp.model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class RegServlet extends HttpServlet {

    private static final UsersDAO dao = new UserDAOImpl();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("utf-8");

        String email = req.getParameter("email");
        String pwd = req.getParameter("pwd");
        String confirmPwd = req.getParameter("confirmPwd");
        String name = req.getParameter("name");
        String details = req.getParameter("details");

        if (pwd.equals(confirmPwd)) {
            User user = new User(email, pwd, name, details);
            dao.createUser(user);
            resp.getWriter().println(email + " has been registered!");
        } else {
            RequestDispatcher reqDisp = req.getRequestDispatcher("RegistrationForm.html");
            resp.getWriter().println("Passwords are not equal");
            reqDisp.include(req, resp);
        }

    }
        @Override
        protected void doGet (HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
            RequestDispatcher reqDisp = req.getRequestDispatcher("RegistrationForm.html");
            reqDisp.forward(req, resp);
        }
    }