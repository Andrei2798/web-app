package main.webapp.jdbc;

import main.webapp.jdbc.dao.UsersDAO;
import main.webapp.jdbc.dao.impl.UserDAOImpl;
import main.webapp.model.User;


public class ConnectionTest {


    public static void main(String[] args) {
        UsersDAO dao = new UserDAOImpl();
//        User user = dao.getUserByEmail("JOHN@gmail.com");
//        System.out.println(user);

        //User user1=new User("Tom@mail.com", "1234", "Tom", "normal");
      //  dao.createUser(user1);
//      dao.updateUser(user1);
        System.out.println(dao.getUserById(16));


    }
}
