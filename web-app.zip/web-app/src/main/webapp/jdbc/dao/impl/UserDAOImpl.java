package main.webapp.jdbc.dao.impl;

import main.webapp.jdbc.dao.UsersDAO;
import main.webapp.model.User;
import main.webapp.util.DBUtils;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;

public class UserDAOImpl implements UsersDAO {

    @Override
    public boolean createUser(User user) {
        String sql = "INSERT INTO `users` (`email`, `pwd`, `name`, `details`) VALUES ('"+user.getEmail()+"', '"+user.getPwd()+"', '"+user.getName()+"', '"+user.getDetails()+"')";
        Connection conn = DBUtils.getConnection();
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            System.out.println("User+ 1");
            return true;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public boolean updateUser(User user) {
        return false;
    }

    @Override
    public boolean deleteUserById(int id) {
        return false;
    }

    @Override
    public User getUserById(int id) {
        final String select = "SELECT * FROM crazy_app_db.users WHERE id = " + id;
        Connection conn = DBUtils.getConnection();
        User user = null;
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(select);
            while (rs.next()){
                user = new User();
                user.setId(id);

                user.setEmail(rs.getString("email"));
                user.setPwd(rs.getString("pwd"));
                user.setName(rs.getString(4));
                user.setDetails(rs.getString(5));
                user.setActive(rs.getString(6).equals("Y"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtils.closeConnection(conn);
        }


        return user;
    }

    @Override
    public User getUserByEmail(String email) {
        final String select = "SELECT * FROM crazy_app_db.users WHERE email = '" + email + "'";
        Connection conn = DBUtils.getConnection();
        User user = null;
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(select);
            while (rs.next()){
                user = new User();
                user.setId(rs.getInt(1));
                user.setEmail(rs.getString("email"));
                user.setPwd(rs.getString("pwd"));
                user.setName(rs.getString(4));
                user.setDetails(rs.getString(5));
                user.setActive(rs.getString(6).equals("Y"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBUtils.closeConnection(conn);
        }

        return user;
    }

    @Override
    public Set<User> getAllUser() {
        return null;
    }

    @Override
    public boolean activateUser(String email)
    {
        String update="UPDATE users SET is_activate='y' WHERE users.email='"+email+"'";
        return false;
    };
}
