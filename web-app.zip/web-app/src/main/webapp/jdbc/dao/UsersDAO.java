package main.webapp.jdbc.dao;

import main.webapp.model.User;

import java.util.Set;

public interface UsersDAO {

    boolean createUser(User user);
    boolean updateUser(User user);
    boolean deleteUserById(int id);
    User getUserById(int id);

    User getUserByEmail(String email);
    Set<User> getAllUser();

    boolean activateUser(String email);


}
