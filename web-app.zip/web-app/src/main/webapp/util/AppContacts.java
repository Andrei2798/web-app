package main.webapp.util;

public class AppContacts
{

}
