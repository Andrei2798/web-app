package main.webapp.util;

public class MailUtils {

}
