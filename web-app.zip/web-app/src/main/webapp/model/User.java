package main.webapp.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {

    private int id;
    private String email;
    private String pwd;
    private String name;
    private String details;
    private boolean isActive;

    public User(String email, String pwd, String name, String details) {
        this.email = email;
        this.pwd=pwd;
        this.name=name;
        this.details=details;
    }
}
